from django.contrib import admin
from .models import *

# Register your models here.


admin.site.register(Film)
admin.site.register(Camera)
admin.site.register(Post)
admin.site.register(Comment)
admin.site.register(Hashtag)
admin.site.register(Scrap)


